<?php the_content(); ?>
<div class="embed-responsive embed-responsive-16by9">
	<iframe class="external-resource-final embed-responsive-item" src=""></iframe>
</div>